﻿using System.Runtime.InteropServices;

namespace Brady.Common.CrystalWrapper
{
    [Guid("CC4BE3B1-F49B-42C8-AB6F-B7E15AE94FB7")]
    public enum PrintOrientation
    {
        Portrait = 1,
        Landscape = 2
    }
}