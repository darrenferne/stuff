﻿using System.Runtime.InteropServices;

namespace Brady.Common.CrystalWrapper
{
    [Guid("F56E97E2-51E5-4044-9EB7-663BCF16B93C")]
    public enum SelectionFormulaType : int
    {
        None = 0,
        Crystal = 1,
        Native = 2
    }
}